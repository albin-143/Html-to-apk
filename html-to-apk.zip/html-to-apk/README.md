# HTML -> APK Template (முழு வசதிகளுடன்)

## பயன்படுத்தும் முறை
1. `app/src/main/assets/index.html` கோப்பை உங்கள் ஆப்பால் மாற்றுங்கள் (CSS, JS, படங்கள் அதே folder-ல்).
2. GitHub-ல் புதிய repo -> இந்த folder முழுவதையும் push செய்யுங்கள்.
3. Actions tab -> "Build APK" முடிந்ததும் Artifacts -> `app-debug` download செய்து APK install செய்யுங்கள்.

## உள்ள வசதிகள்
- localStorage / sessionStorage
- Internet, fetch API
- GPS: navigator.geolocation
- Camera: <input type="file" accept="image/*"> (photo எடுக்கலாம் / கோப்பு தேர்வு)
- Live camera + mic: navigator.mediaDevices.getUserMedia
- File upload: <input type="file">
- Download: http(s) link தானாக Downloads-க்கு; blob/base64-க்கு Android.saveFile(name, mime, base64)
- Android.vibrate(ms), Android.toast(text), Android.share(text)
- tel:, mailto: links, வெளி website links

## மாற்ற வேண்டியவை
- ஆப் பெயர்: AndroidManifest.xml -> android:label
- Package ID: app/build.gradle -> applicationId
- உங்கள் சொந்த website-ஐ load செய்ய: MainActivity.java-ல் START_URL மாற்றி, TRUSTED_HOSTS-ல் அதன் host சேர்க்கவும்.
